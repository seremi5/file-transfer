#!/bin/bash

# This script downloads OpenAPI files from the Sandbox environment and saves them to the "helper/" folder.
# We download only actively supported API versions, and exclude old and future non-released versions.
# We also apply some common non-overlay fixes - e.g. text replacements, and alphabetical schema ordering.
#
# The downloaded OpenAPI specs can then be used as input files for applying overlays (which is a separate script).


# The current API versions to prepare the specs for
# TODO: read this list from the "VERSIONS" file instead
declare -a API_VERSIONS=("2024-05-25" "2024-01-31" "2023-09-01")

# Future API versions that are listed in https://api.dev.monite.com/docs but not released yet.
# Comment out this line if there're NO unreleased versions.
declare -a UNRELEASED_VERSIONS=("2025-06-23")

OUTDIR="helper"

if ! command -v yq >/dev/null 2>&1
then
    echo "ERROR: yq is not installed"
    exit 1
fi
if [ ! -d "$OUTDIR" ]; then
  mkdir -p "$OUTDIR"
fi

for VERSION in "${API_VERSIONS[@]}"; do
  echo "Downloading sandbox OpenAPI for v. $VERSION..."

  # NO SPACES around =
  OUTFILE="$OUTDIR/$VERSION-sandbox.yaml"

  # Download OpenAPI JSON spec from SANDBOX Swagger UI
  # and save it as YAML. Existing files will be overwritten.
  # `?$date` is used to try to bypass the server cache in case of intermittent schema conflicts.
  # (Cache bypass doesn't always work though.)
  curl "https://api.sandbox.monite.com/openapi.json?version=$VERSION&$(date +%s)" \
    -H "Cache-Control: no-cache, no-store" --silent --show-error | yq -P > "$OUTFILE"


  ##############################################
  #   Small fixes.                             #
  #   The -i flag modifies the file in-place.  #
  ##############################################

  # Remove the dev server
  # NB: This fix is here and not in overlays because it's needed for all versions
  yq -i 'del(.servers[] | select(.url == "*.dev.*"))' "$OUTFILE"

  # Delete useless response codes
  yq -i 'del(.paths[] | .. | select(has("responses")) | .responses."405")' "$OUTFILE"
  # yq -i 'del(.paths[] | .. | select(has("responses")) | .responses."500")' "$OUTFILE"

  # Remove future unreleased versions from the APIVersion enum
  # NB: This fix is here and not in overlays because it's needed for all versions
  if [ "$UNRELEASED_VERSIONS" ]; then
    for FUTURE_VER in "${UNRELEASED_VERSIONS[@]}"; do

      # Only remove this version from specs for other versions
      if [ "$FUTURE_VER" != "$VERSION" ]; then
        # This particular quoting around "'"$VAR"'" is required to properly insert the variable value
        # inside a single-quoted string
        yq -i '.components.schemas.APIVersion.enum -= ["'"$FUTURE_VER"'"]' "$OUTFILE"
      fi

    done
  fi

  # Remove internal schema descriptions and
  # boilerplate descriptions like "Helper class that provides a standard way to create an ABC using inheritance."
  # Doing this here because I'm not sure where it comes from in the source code.
  # NB: This fix is here and not in overlays because it's needed for all versions
  yq -i 'del(.components.schemas.ReceivablesStatusEnum.description)' "$OUTFILE"
  yq -i 'del(.components.schemas[] | select(
    .description == "*Helper class that provides*"
      or
    .description == "*Raise if None was explicitly passed to given fields*"
  ).description)' "$OUTFILE"

  # Fix fluctuating (present/absent) descriptions of some Counterpart* schemas
  yq -i '.components.schemas *= {
    "CounterpartIndividualResponse": {
      "description": "Represents counterparts that are individuals (natural persons)."
    },
    "CounterpartOrganizationResponse": {
      "description": "Represents counterparts that are organizations (juridical persons)."
    }
  }' "$OUTFILE"

  # Remove "deleted" status from public enums - because deleted resources are not actually returned from API
  # NB: This fix is here and not in overlays because it's needed for all versions
  yq -i '.components.schemas["CreditNoteStateEnum", "QuoteStateEnum", "ReceivablesStatusEnum"].enum -= ["deleted"]' "$OUTFILE"

  # Version-specific fixes
  case $VERSION in
    2024-05-25)
      # Remove entity "deleted" status ONLY from v. 2024-05-25 and later.
      # In previous versions, the "deleted" status is, in fact, returned as a replacement for "inactive".
      # https://monite.slack.com/archives/C040KCL4LFJ/p1740987129945579?thread_ts=1740769189.651599&cid=C040KCL4LFJ
      yq -i '.components.schemas.EntityStatusEnum.enum -= ["deleted"]' "$OUTFILE"

      # Make sure the PartnerMetadata schema has "additionalProperties: true".
      # It sometimes gets removed and added back, resulting in extra diffs.
      # Add "additionalProperties" as the 1st child key.
      yq -i 'with(.components.schemas.PartnerMetadata.properties.metadata; . |= {"additionalProperties": true} + .)' "$OUTFILE"

      # Make sure the PartnerMetadataResponse schema is nullable and has "additionalProperties: true"
      # to fix fluctuations that result in extra diffs.
      yq -i 'with(.components.schemas.PartnerMetadataResponse.properties.metadata;
        # If there is no "anyOf" key...
        . | select(has("anyOf") | not)
        # ... then prepend it and delete the "type" key (because type will be in anyOf)
        |= {
          "anyOf": [
            {
              "additionalProperties": true,
              "type": "object"
            },
            {
              "type": "null"
            }
          ]
        } + .
        | del(.type)
      )' "$OUTFILE"

      # End of fixes for 2024-05-25
      ;;
    *)
  esac

  # Make sure LineItemsRenderingSettings always use inline $refs to avoid fluctuations.
  # TODO: remove this fix after receivables move to Pydantic v2
  yq -i 'with(.components.schemas.LineItemsRenderingSettings.properties[];
    # If a property uses allOf + $ref, then unwrap the $ref
    . | select(.allOf[] | has("$ref"))  |=  {"$ref": .allOf[0]["$ref"]} + .   | del(.allOf)
  )' "$OUTFILE"

  # Fix fluctuations in LineItemColumnSettings and LineItemNumericColumnSettings schemas:
  # if a property uses inline types, make it anyOf + null.
  # TODO: remove this fix after receivables move to Pydantic v2
  yq -i 'with(.components.schemas["LineItemColumnSettings", "LineItemNumericColumnSettings"].properties[];
    # Exclude boolean properties from this fix
    . | select( (has("anyOf") | not) and has("type") and .type != "boolean") |
    # Move all keys except "description" into anyOf
    . *= {
      "anyOf": [
        . | omit(["description"]),
        {"type": "null"}
      ]
    }
    |= pick(["anyOf", "description"])
  )' "$OUTFILE"

  # Clean up callbacks
  # NB: This fix is here and not in overlays because it's needed for all versions
  yq -i 'del(.paths[] | .. | select(has("callbacks")) | .callbacks.webhook_notification."{$request.body.url}".post.responses."422")' "$OUTFILE"

  # Remove the example value for X-Monite-Entity-Id from /ocr_tasks endpoints,
  # so that the header will be hidden by default in API Playground.
  # NB: This fix is here and not in overlays because it's needed for all versions
  yq -i 'with(.paths;
    (
      ."/ocr_tasks".get,
      ."/ocr_tasks".post,
      ."/ocr_tasks/upload_from_file".post,
      ."/ocr_tasks/{task_id}".get
    ).parameters[] | select(.name | downcase == "x-monite-entity-id") | del(.schema.examples)
  )' "$OUTFILE"


  ##############################################
  #   Temporary fixes until the corresponding  #
  #   source code fixes are deployed.          #
  ##############################################

  # Workaround for https://monite.atlassian.net/browse/DEV-16321
  # Insert "receipt" after "recurrence" into the ObjectType enum, using this approach:
  # https://github.com/mikefarah/yq/discussions/1520
  # An easier way would be to append + sort alphabetically, but unfortunately the enum is not sorted initially.
  yq -i 'with(.components.schemas.ObjectType.enum[] | select(. == "recurrence"); 
    (path | .[-1]) as $i | 
    parent = (parent | .[:$i+1]) + ["receipt"] + (parent | .[$i+1:]) 
  )' "$OUTFILE"

  # NB: these sed commands work only on Mac but not on *nix (due to lack of cross-platform syntax)
  sed -i '' -e 's/E-invoicing Search/E-invoicing search/g' "$OUTFILE"
  sed -i '' -e 's/exist in the network./exist in the network/g' "$OUTFILE"

  # SEO fixes - update old ReadMe-style links to avoid redirects
  sed -i '' -e 's!docs/currencies!references/currencies!g' "$OUTFILE"
  sed -i '' -e 's!Basics_of_HTTP/MIME_types!MIME_types!g' "$OUTFILE"

  # Typos
  sed -i '' -e 's/Project id of/Project ID of/g' "$OUTFILE"

  # Fix spelling of "PDF" in entity settings
  sed -i '' -e 's/ pdf / PDF /g' "$OUTFILE"

  # Fix wrong word in *FileSchema.created_at description
  sed -i '' -e 's/this workflow/this file/g' "$OUTFILE"

  # Restore missing request body for old (deprecated) /documents endpoints
  # TODO: Remove this after https://monite.atlassian.net/browse/DEV-13278 is fixed & released
  # NB: This fix is here and not in overlays because it's needed for all versions
  yq -i 'with (.paths."/entities/{entity_id}/documents".post;
     . += {
        "requestBody": {
          "content": {
            "multipart/form-data": {
              "schema": {
                "$ref": "#/components/schemas/EntityOnboardingDocuments"
              }
            }
          }
        }
      } )|

    with (.paths."/persons/{person_id}/documents".post;
      . += {
        "requestBody": {
          "content": {
            "multipart/form-data": {
              "schema": {
                "$ref": "#/components/schemas/PersonOnboardingDocuments"
              }
            }
          }
        }
      } )|

    with (.components.schemas;
      . += {
      "EntityOnboardingDocuments": {
        "properties": {
          "verification_document_front": {
            "type": "string",
            "format": "binary"
          },
          "verification_document_back": {
            "type": "string",
            "format": "binary"
          },
          "additional_verification_document_front": {
            "type": "string",
            "format": "binary"
          },
          "additional_verification_document_back": {
            "type": "string",
            "format": "binary"
          },
          "bank_account_ownership_verification": {
            "items": {
              "type": "string",
              "format": "binary"
            },
            "type": "array",
            "minItems": 1
          },
          "company_license": {
            "items": {
              "type": "string",
              "format": "binary"
            },
            "type": "array",
            "minItems": 1
          },
          "company_memorandum_of_association": {
            "items": {
              "type": "string",
              "format": "binary"
            },
            "type": "array",
            "minItems": 1
          },
          "company_ministerial_decree": {
            "items": {
              "type": "string",
              "format": "binary"
            },
            "type": "array",
            "minItems": 1
          },
          "company_registration_verification": {
            "items": {
              "type": "string",
              "format": "binary"
            },
            "type": "array",
            "minItems": 1
          },
          "company_tax_id_verification": {
            "items": {
              "type": "string",
              "format": "binary"
            },
            "type": "array",
            "minItems": 1
          },
          "proof_of_registration": {
            "items": {
              "type": "string",
              "format": "binary"
            },
            "type": "array",
            "minItems": 1
          }
        },
        "type": "object"
      },
      "PersonOnboardingDocuments": {
        "properties": {
          "verification_document_front": {
            "type": "string",
            "format": "binary"
          },
          "verification_document_back": {
            "type": "string",
            "format": "binary"
          },
          "additional_verification_document_front": {
            "type": "string",
            "format": "binary"
          },
          "additional_verification_document_back": {
            "type": "string",
            "format": "binary"
          }
        },
        "type": "object"
      }
    }
  )' "$OUTFILE"


  ##############################################
  #   Find common misspelled keywords,         #
  #   Remove invalid keywords                  #
  ##############################################

  # Remove the extra `schema_name` key (it sometimes appears in 2023-04-12)
  yq -i 'del(.. | select(has("schema_name")).schema_name)' "$OUTFILE"
  # Remove the extra `serialization_alias` key from mailer schemas
  # TODO: print a warning if `serialization_alias` is found - similar to gte/lte below
  yq -i 'del(.. | select(has("serialization_alias")).serialization_alias)' "$OUTFILE"

  # Alert if `gte` or `lte` keywords are present
  if yq -e '[.. | has("lte") or has("gte")] | any' "$OUTFILE" > /dev/null 2>&1
  then
    # Find properties containing the "lte" and/or "gte" key,
    # then print "SchemaName.PropertyName" and the property definition
    yq '.. | select(has("lte") or has("gte")) | {path - ["components", "schemas", "properties"] | join("."): .}' "$OUTFILE"

    echo ""
    echo "WARNING: Unexpected keywords found: 'gte' and/or 'lte'."
    echo ""
    echo "Ask developers to fix the schema annotations in the source code:"
    echo "* for numeric fields, replace 'gte' -> 'ge', 'lte' -> 'le'"
    echo "* for string fields, replace 'gte' -> 'min_length', 'lte' -> 'max_length'"
    echo ""
    echo "In the meantime, please also fix the downloaded OpenAPI spec (*-sandbox.yaml) manually:"
    echo "* for numeric fields, replace 'gte' -> 'minimum', 'lte' -> 'maximum'"
    echo "* for string fields, replace 'gte' -> 'minLength', 'lte' -> 'maxLength'"
    echo "-----------------------------------------------------------------------"
    echo ""
  fi;

  # Sort the schemas. Should be at the very end - because some of the fixes above insert missing schemas
  yq -iP 'sort_keys(.components.schemas)' "$OUTFILE"
  # or if we need case-insensitive search:
  # yq -i '.components.schemas |= sort_by(key | downcase)' "$OUTFILE"


  # Since we currently do NOT apply overlays to older API versions,
  # we can just copy those versions directly to the Fern folder
  if [ "$VERSION" != "2024-05-25" ]; then
    FERN_OUTFILE="fern/apis/v$VERSION/openapi/$VERSION.yaml"
    # Create the output folder if it doesn't exist
    mkdir -p `dirname "$FERN_OUTFILE"`
    # -f overwrites the destination file
    cp -f "$OUTFILE" "$FERN_OUTFILE"
  fi
done
