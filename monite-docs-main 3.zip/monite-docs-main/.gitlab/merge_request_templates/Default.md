### Please check if the MR fulfills these requirements

#### General

- [ ] I attached the Jira task to the merge request name

#### If files/folders were moved or renamed

- [ ] I updated file paths AND slugs in <abbr title="table of contents">TOC</abbr> (navigation)
- [ ] I also moved/renamed the same files & folders in all previous versions
- [ ] I checked and, if needed, updated links in Markdown text
- [ ] I updated `canonical-url` in the frontmatter of moved/renamed pages in all previous versions
- [ ] I added redirects to `docs.yml`

#### If pages were deleted

- [ ] I added redirects to `docs.yml` (if appropriate)

#### Code-specific

If this MR includes code updates (e.g. custom components or JavaScript/CSS for the hosting platform):

- [ ] I think the code is well written
- [ ] I have performed a self-review of my code
- [ ] I believe I have written tests for all cases that make sense
- [ ] I ran the checks and tests locally and they passed without errors
- [ ] Security impact of change has been considered
- [ ] Code follows company security practices and guidelines
