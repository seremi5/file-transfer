#!/usr/bin/env node

/**
 * Script to remove JSX comments from all .mdx files in a directory, recursively.
 * Usage: node remove_jsx_comments.js <directory>
 */

const fs = require('fs');
const path = require('path');

// Get the directory path from command line arguments
const targetDir = process.argv[2];

if (!targetDir) {
  console.error('Please provide a directory path.');
  console.error('Usage: node remove_jsx_comments.js <directory>');
  process.exit(1);
}

// Verify the directory exists
if (!fs.existsSync(targetDir) || !fs.statSync(targetDir).isDirectory()) {
  console.error(`Error: Directory '${targetDir}' does not exist`);
  process.exit(1);
}

try {
  console.log('Removing JSX comments from source files...')
  processDirectory(targetDir);
  console.log('Finished removing JSX comments');
} catch (err) {
  console.error(`Error: ${err.message}`);
  process.exit(1);
}

/**
 * Recursively find and process .mdx files in a directory
 * @param {string} dir - Directory to process
 */
function processDirectory(dir) {
  const fpaths = fs.readdirSync(dir);

  // paths includes both files and sub-directories
  for (const fpath of fpaths) {
    const fullPath = path.join(dir, fpath);

    const stats = fs.statSync(fullPath);
    if (stats.isDirectory()) {
      // Recursively process subdirectories
      processDirectory(fullPath);
    } else if (fpath.toLowerCase().endsWith('.mdx')) {
      processFile(fullPath);
    }
  }
}

/**
 * Remove JSX comments from the specified file.
 * @param {string} filePath - Fully-qualified path to the file
 */
function processFile(filePath) {
  //console.log(`Processing: ${filePath}`);

  try {
    let content = fs.readFileSync(filePath, 'utf8');

    const regex = /\{\/\*.*?\*\/\}/gs;
    const newContent = content.replace(regex, '');

    fs.writeFileSync(filePath, newContent);
  } catch (err) {
    console.error(`Error processing ${filePath}: ${err.message}`);
  }
}
