This folder contains Monite OpenAPI specs downloaded from the Sandbox environment.
These files combined with [`../overlays`](../overlays/) are used to create
the final "polished" OpenAPI files for the API reference.

> [!note]
> Do NOT edit these files manually.
> They are created/updated automatically by the `download_openapi.sh` script.
