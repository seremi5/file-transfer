#!/bin/bash

# Applies all overlay files (.yaml) from the "overlays/" folder & its subfolders
# to the base OpenAPI file. The base OpenAPI file is taken from the "helper/" folder.
# The resulting OpenAPI file is saved to:
#   fern/apis/v<version>/openapi/<version>.yaml
# Existing file will be overwritten. The output folder will be created if it does not exist.
#
# Currently, overlays are applied only to the latest API version (which is hard-coded in this script).
# 
# Usage:
#   ./apply-overlays.sh

OVERLAYS_DIR="overlays"
TEMPLATE="_TEMPLATE.yaml" # Overlay template, needs to be ignored
VERSION="2024-05-25"      # TODO: take the latest date from the "VERSIONS" file
INFILE="helper/$VERSION-sandbox.yaml"
OUTFILE="fern/apis/v$VERSION/openapi/$VERSION.yaml"
OUTFILE_TMP="helper/$VERSION-WIP.yaml"  # We'll apply overlays incrementally to a temporary file

if [ ! -f "$INFILE" ]; then
    echo "ERROR: Input OpenAPI file '$INFILE' does not exist" >&2
    exit 1
fi
if [ ! -d "$OVERLAYS_DIR" ]; then
    echo "ERROR: Directory '$OVERLAYS_DIR' does not exist" >&2
    exit 1
fi
if ! command -v bump >/dev/null 2>&1
then
    echo "ERROR: Bump.sh CLI (bump) is not installed"
    exit 1
fi
if ! command -v rdme >/dev/null 2>&1
then
    echo "ERROR: ReadMe CLI (rdme) is not installed"
    exit 1
fi

EXIT_CODE=0

# Disable some Node-related warnings from rdme
export NODE_OPTIONS="--disable-warning=ExperimentalWarning"

# -f overwrites the file
cp -f "$INFILE" "$OUTFILE_TMP"

# ... -print0 ... while IFS=...   is used to properly handle file names containing spaces
find "$OVERLAYS_DIR" -type f -iname "*.yaml" ! -name "$TEMPLATE" -print0 | sort -z | while IFS= read -r -d $'\0' OVERLAY; do
    echo ""
    echo "Applying overlay '$OVERLAY'..."

    # TODO: validate the overlay, e.g.
    # speakeasy overlay validate -o "$OVERLAY"  [--log-level info/warn/error]

    # bump does NOT set non-zero status code in case of overlay warnings/errors
    # so we instead grep the stderr for error/warnings to check the status.
    # In case of no errors, suppress both stdout and stderr (because stdout contains file overwrite confirmations
    # and stderr contains some generic info messages).
    BUMP_STDERR=$(echo y | bump overlay "$OUTFILE_TMP" "$OVERLAY" --out="$OUTFILE_TMP" 2>&1 >/dev/null)
    if echo "$BUMP_STDERR" | grep -v "update available" | grep -iq -e warning -e error; then
        echo "$BUMP_STDERR" >&2
        EXIT_CODE=1
        break
    fi

    # Validate the WIP OpenAPI, in case the overlay introduced regressions
    if ! rdme openapi validate "$OUTFILE_TMP" 2>&1 >/dev/null; then
        EXIT_CODE=1
        break
    fi
done
if [ $EXIT_CODE -ne 0 ]; then
    exit 1
fi

# Expand/resolve any YAML anchors/aliases
yq -i 'explode(.)' "$OUTFILE_TMP"

# Remove unused schemas
while : ; do
    # Used schemas = $ref'erenced schemas. Our discriminator mappings are $ref-based too.
    # LC_COLLATE=C is used for case-sensitive sorting (to keep the old sort order).
    export USED_SCHEMAS="$(grep -oE '#/components/schemas/[A-Za-z0-9\._-]+' "$OUTFILE_TMP" \
        | sed 's|#/components/schemas/|- |' \
        | LC_COLLATE=C sort -u)"
    # If components.schemas contains any unused schemas ...
    if yq -e '.components.schemas | keys - env(USED_SCHEMAS) | any' "$OUTFILE_TMP" > /dev/null 2>&1; then
        # ... keep only used schemas; repeat until there're no unused ones
        yq -i '.components.schemas |= pick(env(USED_SCHEMAS))' "$OUTFILE_TMP"
    else
        break
    fi
done
# Alternative way to remove unused schemas - in case yq approach is too complex to maintain:
#   1) Rewrite openapi-collector's "remove_unused_schemas" function in Node.js for use in docs
#      https://gitlab.monite.com/monite/backend/lithosphere/openapi-collector/-/blob/master/utils/openapi.py?ref_type=heads#L414
#   3) openapi-format --filterFile [YAML file with "unusedComponents" option]
#      https://www.npmjs.com/package/openapi-format/v/1.8.0#openapi-filter-options
#   3) redocly bundle --remove-unused-components ...   or a similar config in decorators.yml
#      https://redocly.com/docs/cli/decorators/remove-unused-components
#      Bugs:
#       https://github.com/Redocly/redocly-cli/issues/1209
#       https://github.com/Redocly/redocly-cli/issues/1783


# Set the order of top-level nodes
yq -iP 'pick( (["openapi", "info", "servers", "paths", "components", "tags"] + keys) | unique)' "$OUTFILE_TMP"

# Create the output folder if it doesn't exist
mkdir -p `dirname "$OUTFILE"`
# -f overwrites the destination file
mv -f "$OUTFILE_TMP" "$OUTFILE"
