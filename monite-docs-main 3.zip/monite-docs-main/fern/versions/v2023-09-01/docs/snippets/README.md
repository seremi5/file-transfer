This folder contains [_snippets_](https://buildwithfern.com/learn/docs/content/reusable-snippets) (also known as _partials_, _includes_, or _conrefs_) used in the given version of the documentation.

Common snippets shared between all versions are in the `/fern/snippets` folder.
