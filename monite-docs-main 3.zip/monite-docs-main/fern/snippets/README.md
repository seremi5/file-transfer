This folder contains common [_snippets_](https://buildwithfern.com/learn/docs/content/reusable-snippets) (also known as _partials_, _includes_, or _conrefs_) that are shared between all versions of the documentation.

Version-specific snippets are in `versions/<version>/snippets/` folder.
