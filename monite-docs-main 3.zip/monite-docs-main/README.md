This repository contains the source code and OpenAPI files for Monite documentation https://docs.monite.com.
Our documentation is built with [Fern](https://www.buildwithfern.com/).

[[_TOC_]]

## Contributing

See [Contributing to Monite documentation](https://www.notion.so/monite/Contributing-to-Monite-documentation-1187d1d3749780d48f9ad75d542ee57b).

## Requirements
* Node.js
* Fern CLI: `npm install fern-api -g`

For overlays:
* [yq](https://github.com/mikefarah/yq/): `brew install yq`
  * tested with v. 4.45.4
* [Bump.sh CLI](https://github.com/bump-sh/cli#readme): `npm install bump-cli -g`
* [Readme CLI](https://github.com/readmeio/rdme#readme) (for OpenAPI validation): `npm install rdme -g`

## Repository structure

* `fern` - Markdown pages, images, etc., and Fern configs.
* `helper` - "base" OpenAPI files downloaded from the Sandbox environment.
  These are used to create the final OpenAPI files used for the API reference.
* `overlays` - OpenAPI overlays containing additional descriptions, payload examples, and fixes for our OpenAPI spec.
  These overlays are applied on top of the base OpenAPI spec (taken from `helper/`) and copied to `fern/apis/v<version>/openapi/<version>.yaml` for use in docs.
* `scripts` - helper scripts used in CI/CD.

## How to...

### Preview docs locally

```sh
fern docs dev
```
starts a server on http://localhost:3000 (or another port if 3000 is taken).

Or if you've updated overlays:

```sh
./apply_overlays.sh && fern docs dev
```

### Update OpenAPI specs

1. Download the specs from Sandbox:

   ```sh
   ./download_openapi.sh
   ```

2. Carefully review the diffs in `helper/` files to make sure there're no unwanted changes
   (such as new endpoints are are not supposed to be released yet).
   If needed, create an overlay to fix those unwanted changes.

3. Apply overlays:

   ```sh
   ./apply_overlays.sh
   ```
